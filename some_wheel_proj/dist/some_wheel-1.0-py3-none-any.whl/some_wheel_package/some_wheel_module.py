def some_func():
    return "some_func from some_wheel_proj"
